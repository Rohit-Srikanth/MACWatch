import subprocess
import platform
import re

def get_os():
    return platform.system().lower()

def get_arp_table():
    os_type = get_os()
    arp_table = {}

    if os_type == "windows":
        output = subprocess.check_output("arp -a", shell=True).decode()
        pattern = r"(\d+\.\d+\.\d+\.\d+)\s+([\w-]+)"
    else:  # Linux or Mac
        output = subprocess.check_output(["arp", "-n"]).decode()
        pattern = r"(\d+\.\d+\.\d+\.\d+)\s+.*?(([0-9a-f]{2}:){5}[0-9a-f]{2})"

    matches = re.findall(pattern, output, re.IGNORECASE)
    for match in matches:
        ip = match[0]
        mac = match[1].replace("-", ":") if "-" in match[1] else match[1]
        arp_table[ip] = mac.lower()

    return arp_table

def get_interface_ip():
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip
