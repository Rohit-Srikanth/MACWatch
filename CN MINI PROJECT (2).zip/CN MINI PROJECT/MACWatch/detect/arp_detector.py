from scapy.all import sniff, ARP
import time
from MACWatch.utils.netwatch import get_arp_table



# Store known MAC addresses for the IPs
arp_table = {}

def detect(pkt):
    if pkt.haslayer(ARP) and pkt[ARP].op == 2:  # ARP Reply
        ip = pkt[ARP].psrc
        mac = pkt[ARP].hwsrc
        
        # If the IP is already in the table but the MAC is different, it's a spoof
        if ip in arp_table and arp_table[ip] != mac:
            print(f"[!] Possible ARP Spoof Detected: {ip} is now {mac}, was {arp_table[ip]}")
        else:
            arp_table[ip] = mac

    # For logging or additional actions, use the ARP table
    print("Current ARP table:", arp_table)

# Start sniffing ARP packets to detect spoofing
print("Starting ARP spoofing detection...")
sniff(filter="arp", prn=detect, store=0)
